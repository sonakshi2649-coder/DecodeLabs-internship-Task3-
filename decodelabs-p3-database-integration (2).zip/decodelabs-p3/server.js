require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const app = express();
const PORT = process.env.PORT || 5000;

// ─────────────────────────────────
// Connect to Database (Pillar 2: The Bridge)
// ─────────────────────────────────
connectDB();

// ─────────────────────────────────
// Middleware
// ─────────────────────────────────
app.use(cors());                    // Allow cross-origin requests
app.use(express.json());            // Parse incoming JSON bodies
app.use(express.urlencoded({ extended: true }));

// ─────────────────────────────────
// API Routes (Pillar 3: The Action — CRUD + RESTful HTTP)
// ─────────────────────────────────
app.use('/api/users', require('./routes/users'));

// Health check route
app.get('/', (req, res) => {
  res.json({
    message: '🚀 DecodeLabs P3 — Database Integration API is running',
    status: 'OK',
    endpoints: {
      createUser:  'POST   /api/users',
      getAllUsers:  'GET    /api/users',
      getUserById: 'GET    /api/users/:id',
      updateUser:  'PUT    /api/users/:id',
      patchUser:   'PATCH  /api/users/:id',
      deleteUser:  'DELETE /api/users/:id',
    },
  });
});

// ─────────────────────────────────
// 404 Handler — unknown routes
// ─────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

// ─────────────────────────────────
// Global Error Handler (Pillar 4: The Shield)
// ─────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Internal Server Error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined,
  });
});

app.listen(PORT, () => {
  console.log(`\n🚀 Server running at http://localhost:${PORT}`);
  console.log(`📄 DecodeLabs Project 3 — Database Integration`);
  console.log(`🌿 Batch 2026 | Powered by DecodeLabs\n`);
});
