# DecodeLabs Project 3 — Database Integration
**Batch 2026 | Full Stack Development | Powered by DecodeLabs**

---

## Project Goal
Connect the backend with a database to store and retrieve data permanently using the four pillars:
- **Pillar 1 — The Blueprint**: Schema & Database Design
- **Pillar 2 — The Bridge**: Integration & DB Connection
- **Pillar 3 — The Action**: CRUD & RESTful HTTP
- **Pillar 4 — The Shield**: Data Integrity & Security

---

## Tech Stack
| Layer | Technology |
|-------|-----------|
| Runtime | Node.js |
| Framework | Express.js |
| Database | MongoDB (via Mongoose ORM) |
| Validation | express-validator |
| Environment | dotenv |

---

## Project Structure
```
decodelabs-p3/
├── config/
│   └── db.js           ← MongoDB connection (Pillar 2)
├── models/
│   └── User.js         ← Schema with constraints (Pillar 1)
├── routes/
│   └── users.js        ← CRUD endpoints (Pillar 3 + 4)
├── .env.example        ← Environment variable template
├── .gitignore
├── package.json
└── server.js           ← App entry point
```

---

## Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
```bash
# Copy the example file
cp .env.example .env

# Edit .env and set your MongoDB URI
# Option A — MongoDB Atlas (cloud): recommended
MONGO_URI=mongodb+srv://<user>:<pass>@cluster0.xxxxx.mongodb.net/decodelabs_p3

# Option B — Local MongoDB
MONGO_URI=mongodb://localhost:27017/decodelabs_p3
```

### 3. Start the Server
```bash
# Production
npm start

# Development (auto-restart on file changes)
npm run dev
```

Server runs at: **http://localhost:5000**

---

## API Reference — CRUD Mapping (as taught in P3)

| CRUD | HTTP Method | SQL Equivalent | Endpoint |
|------|------------|---------------|----------|
| Create | POST | INSERT | `POST /api/users` |
| Read All | GET | SELECT * | `GET /api/users` |
| Read One | GET | SELECT WHERE | `GET /api/users/:id` |
| Update | PUT | UPDATE | `PUT /api/users/:id` |
| Partial Update | PATCH | UPDATE (partial) | `PATCH /api/users/:id` |
| Delete | DELETE | DELETE | `DELETE /api/users/:id` |

---

## API Testing with cURL / Postman

### ✅ CREATE a User — POST
```bash
curl -X POST http://localhost:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Alice Singh",
    "email": "alice@decodelabs.tech",
    "age": 22,
    "role": "student"
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "_id": "64f1a...",
    "name": "Alice Singh",
    "email": "alice@decodelabs.tech",
    "age": 22,
    "role": "student",
    "isActive": true,
    "createdAt": "2025-01-01T10:00:00.000Z"
  }
}
```

---

### 📖 READ ALL Users — GET
```bash
curl http://localhost:5000/api/users

# With filters
curl "http://localhost:5000/api/users?role=student&page=1&limit=5"

# With search
curl "http://localhost:5000/api/users?search=alice"
```

---

### 📖 READ One User — GET by ID
```bash
curl http://localhost:5000/api/users/<id>
```

---

### ✏️ UPDATE a User — PUT (full update)
```bash
curl -X PUT http://localhost:5000/api/users/<id> \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Alice Sharma",
    "email": "alice@decodelabs.tech",
    "age": 23,
    "role": "instructor"
  }'
```

---

### 🩹 PARTIAL UPDATE — PATCH
```bash
curl -X PATCH http://localhost:5000/api/users/<id> \
  -H "Content-Type: application/json" \
  -d '{ "isActive": false }'
```

---

### 🗑️ DELETE a User — DELETE
```bash
curl -X DELETE http://localhost:5000/api/users/<id>
```

---

## Schema Design — Constraints Implemented (Pillar 1 + 4)

| Constraint | Field | Rule |
|-----------|-------|------|
| NOT NULL | name, email, age | `required: true` |
| UNIQUE | email | `unique: true` |
| CHECK | age | `min: 18` |
| CHECK | role | `enum: ['student', 'instructor', 'admin']` |
| AUTO | createdAt, updatedAt | `timestamps: true` |

---

## Security — SQL Injection Prevention (Pillar 4)

Mongoose uses **parameterized queries** internally — user input is never concatenated
into raw query strings. This is equivalent to the parameterized queries pattern shown
in the DecodeLabs slides (Pillar 4: The Shield).

```js
// ❌ Vulnerable (raw concatenation — shown in slides as what NOT to do)
db.query("SELECT * FROM users WHERE email = '" + userInput + "'");

// ✅ Safe — what Mongoose does internally
User.findOne({ email: req.body.email });  // Input treated as data, never executable logic
```

---

## Submission Checklist
- [x] Database schema designed with proper constraints
- [x] MongoDB connected via Mongoose (ORM)
- [x] CRUD — Create (POST) implemented
- [x] CRUD — Read All + Read One (GET) implemented
- [x] CRUD — Update (PUT + PATCH) implemented
- [x] CRUD — Delete (DELETE) implemented
- [x] Input validation with proper error messages
- [x] UNIQUE and NOT NULL constraints enforced
- [x] Parameterized queries (no SQL injection risk)
- [x] RESTful HTTP verbs correctly mapped to DB operations

---

*DecodeLabs Batch 2026 — Project 3: Database Integration*
