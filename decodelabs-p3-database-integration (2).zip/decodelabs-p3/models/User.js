const mongoose = require('mongoose');

// Schema Design — Pillar 1: The Blueprint
// Applying constraints: UNIQUE, NOT NULL, CHECK (as taught in DecodeLabs P3)
const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],   // NOT NULL equivalent
      trim: true,
      minlength: [2, 'Name must be at least 2 characters'],
      maxlength: [50, 'Name cannot exceed 50 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],  // NOT NULL equivalent
      unique: true,                            // UNIQUE constraint
      lowercase: true,
      trim: true,
      match: [
        /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
        'Please enter a valid email address',
      ],
    },
    age: {
      type: Number,
      required: [true, 'Age is required'],
      min: [18, 'Age must be at least 18'],    // CHECK constraint: age >= 18
      max: [120, 'Age must be a valid number'],
    },
    role: {
      type: String,
      enum: ['student', 'instructor', 'admin'], // Restricts allowed values
      default: 'student',
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Virtual field: does NOT get saved to DB, just computed on the fly
userSchema.virtual('summary').get(function () {
  return `${this.name} (${this.role}) — ${this.email}`;
});

module.exports = mongoose.model('User', userSchema);
