const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const User = require('../models/User');

// ─────────────────────────────────────────────
// Validation rules (reusable middleware)
// ─────────────────────────────────────────────
const userValidationRules = [
  body('name')
    .notEmpty().withMessage('Name is required')
    .isLength({ min: 2, max: 50 }).withMessage('Name must be 2–50 characters'),
  body('email')
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Enter a valid email'),
  body('age')
    .notEmpty().withMessage('Age is required')
    .isInt({ min: 18 }).withMessage('Age must be at least 18'),
  body('role')
    .optional()
    .isIn(['student', 'instructor', 'admin']).withMessage('Invalid role'),
];

// Middleware: check validation results
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};

// ─────────────────────────────────────────────
// CREATE — POST /api/users
// HTTP POST = SQL INSERT (DecodeLabs P3 Mapping)
// ─────────────────────────────────────────────
router.post('/', userValidationRules, validate, async (req, res) => {
  try {
    const { name, email, age, role } = req.body;
    const user = await User.create({ name, email, age, role });
    res.status(201).json({
      success: true,
      message: 'User created successfully',
      data: user,
    });
  } catch (error) {
    // Handle duplicate email (UNIQUE constraint violation)
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: 'Email already exists. Use a unique email address.',
      });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});

// ─────────────────────────────────────────────
// READ ALL — GET /api/users
// HTTP GET = SQL SELECT (DecodeLabs P3 Mapping)
// Supports: ?role=student, ?search=alice, ?page=1&limit=10
// ─────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { role, search, page = 1, limit = 10 } = req.query;

    // Build query filter dynamically
    const filter = {};
    if (role) filter.role = role;
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    const total = await User.countDocuments(filter);
    const users = await User.find(filter)
      .select('-__v')          // Exclude internal Mongoose field
      .sort({ createdAt: -1 }) // Newest first
      .skip(skip)
      .limit(Number(limit));

    res.status(200).json({
      success: true,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / Number(limit)),
      count: users.length,
      data: users,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ─────────────────────────────────────────────
// READ ONE — GET /api/users/:id
// ─────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-__v');
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.status(200).json({ success: true, data: user });
  } catch (error) {
    // Invalid MongoDB ObjectId format
    if (error.name === 'CastError') {
      return res.status(400).json({ success: false, message: 'Invalid user ID format' });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});

// ─────────────────────────────────────────────
// UPDATE — PUT /api/users/:id
// HTTP PUT = SQL UPDATE (DecodeLabs P3 Mapping)
// Full update. Use PATCH for partial updates.
// ─────────────────────────────────────────────
router.put('/:id', userValidationRules, validate, async (req, res) => {
  try {
    const { name, email, age, role, isActive } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, age, role, isActive },
      {
        new: true,            // Return updated document
        runValidators: true,  // Run schema validators on update
      }
    );
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.status(200).json({
      success: true,
      message: 'User updated successfully',
      data: user,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: 'Email already in use' });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});

// ─────────────────────────────────────────────
// PARTIAL UPDATE — PATCH /api/users/:id
// Update only the fields sent in the request body
// ─────────────────────────────────────────────
router.patch('/:id', async (req, res) => {
  try {
    const updates = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true, runValidators: true }
    );
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.status(200).json({
      success: true,
      message: 'User partially updated',
      data: user,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ─────────────────────────────────────────────
// DELETE — DELETE /api/users/:id
// HTTP DELETE = SQL DELETE (DecodeLabs P3 Mapping)
// ─────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.status(200).json({
      success: true,
      message: `User "${user.name}" deleted successfully`,
      data: user,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
